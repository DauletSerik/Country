# REST Country APP in React
This applicaiton is displaying countries along with their information like full country name, country languages, currency, location on map, etc. It is using REST Country API that sends countries information.
